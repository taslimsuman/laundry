<?php $__env->startSection('content'); ?>
<div class="alert alert-danger">
        <ul>
           <li><?php echo e($exception->getMessage()); ?></li>
        </ul>
    </div>

<a href="<?php echo e(url('/login')); ?>" class="btn btn-info">Login</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>