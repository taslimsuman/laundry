<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="panel panel-default">
	  <div class="panel-heading">
        <h3>Update information</h3>
    </div>
     <div class="panel-body">
         <form class="form-row" method="post" action="<?php echo e(url('settings')); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="row">
                <div class="form-group col-md-8">
                    <label>Name</label>
                    <input type="text" name="name" value="<?php echo e($shop->name); ?>" class="form-control">
                </div>
                
            </div>
            <div class="row">
                <div class="form-group col-md-4">
                    <label>Address</label>
                    <input type="text" name="address" value="<?php echo e($shop->address); ?>" class="form-control">
                </div>

                <div class="form-group col-md-4">
                    <label>Contact</label>
                    <input type="text" name="contact" value="<?php echo e($shop->contact); ?>" class="form-control">
                </div>
                
            </div>
            
            <div class="row">
                <div class="form-group col-md-4">
                    <label>Email</label>
                    <input type="text" name="email" value="<?php echo e($shop->email); ?>" class="form-control">
                </div>
                <div class="form-group col-md-4">
                    <label>Website</label>
                    <input type="text" name="website" value="<?php echo e($shop->website); ?>" class="form-control">
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-4">
                    <label>Tax No</label>
                    <input type="text" name="tax_no" value="<?php echo e($shop->tax_no); ?>" class="form-control">
                </div>
                <div class="form-group col-md-4">
                    <label>Tax%</label>
                    <input type="text" name="tax_percent" value="<?php echo e($shop->tax_percent); ?>" class="form-control">
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-4">
                    <label>Currency</label>
                    <input type="text" name="currency" value="<?php echo e($shop->currency); ?>" class="form-control">
                    
                </div>
            </div>

            <div class="row">
                <div class="form-group col-md-4">
                    <label>Logo</label>
                    <input type="file" name="logo">
                </div>
                <div class="form-group col-md-4">
                    <?php if($shop->logo): ?>
                    <img src="<?php echo e(asset('/upload')); ?>/<?php echo e($shop->logo); ?>" class="img-responsive" width="75px">
                    <?php endif; ?>
                </div>
            </div>
            
            <input type="submit" value="Update" class="btn btn-success">
            <a href="<?php echo e(url('/dashboard')); ?>" class="btn btn-default">Cancel</a>
        </form>

    </div>
</div>
<!-- endpanel -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>