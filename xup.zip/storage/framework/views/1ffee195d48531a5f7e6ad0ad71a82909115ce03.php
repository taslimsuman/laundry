<?php echo $__env->make('layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
	  <div class="panel-heading">
        <h3>User Update</h3>
    </div>
     <div class="panel-body">
         <form class="form-row" method="post" action="<?php echo e(url('/user/update',$user->id)); ?>" autocomplete="off">
            <?php echo e(csrf_field()); ?>

            <div class="row">
                <div class="form-group col-md-4">
                    <label>Name</label>
                    <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control">
                </div>
                <div class="form-group col-md-4">
                    <label>Email</label>
                    <input type="text" name="email" value="<?php echo e($user->email); ?>" class="form-control" autocomplete="off">
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-4">
                    <label>Role</label>
                    
                    <select name="role_id" class="form-control">
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>" <?php echo e($role->id==$user->role_id?'selected':''); ?>><?php echo e($role->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-md-4">
                    <label>Status</label>
                    <select name="status" class="form-control">
                        <option value="1" <?php echo e($user->status==1?'selected':''); ?>>Active</option>
                        <option value="0" <?php echo e($user->status==0?'selected':''); ?>>Inactive</option>                
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-4">
                    <label>Password</label>
                    <input type="password" name="new_password" value="" class="form-control" autocomplete="off">
                </div>
                <div class="form-group col-md-4">
                    <label></label>
                    
                </div>
            </div>
            
            <input type="submit" value="Update" class="btn btn-success">
        </form>

    </div>
</div>
<!-- endpanel -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>