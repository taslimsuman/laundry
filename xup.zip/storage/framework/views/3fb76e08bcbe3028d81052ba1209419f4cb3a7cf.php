

<a href="<?php echo e(url('/login')); ?>" class="btn btn-primary">Login</a>