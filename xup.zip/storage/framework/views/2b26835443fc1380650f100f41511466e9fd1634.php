<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-4">
<div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="<?php echo e(asset('upload/taslim.jpg')); ?>" alt="User profile picture">

              <h3 class="profile-username text-center">Taslim</h3>

              <p class="text-muted text-center">Web Developer</p>

             
			<p>Please provide your feedback to improve this application</p>
              <a href="#" class="btn btn-primary ">
              	<i class="fa fa-facebook"></i>
              </a>
              <a href="wa.me" class="btn btn-success ">
              	<i class="fa fa-whatsapp"></i>
              </a>
            </div>
            <!-- /.box-body -->
          </div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>