<?php $__env->startSection('header',$status); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="panel panel-default">
     <div class="panel-body">
         <form action="url('invoice/search/result')" method="get">
          <?php echo csrf_field(); ?>
          <div class="row">
          		<div class="col-md-2">
	            	<label>Invoice No</label>
	           		<input type="text" name="invoice" class="form-control">
	          	</div>

	            <div class="col-md-3">
	            <label>Name</label>
	           		<input type="text" name="name" class="form-control">
	          	</div>
              <div class="col-md-2">
                <label>Mobile No</label>
                <input type="text" name="customer_contact" class="form-control">
              </div>
              <div class="col-md-2">
                <label>Action</label><br>
                <input type="submit" value="Search" class="btn btn-success">
                <a href="<?php echo e(url('invoices')); ?>" class="btn btn-default">Cancel</a>
              </div>
          </div>
        </form>
    </div>
</div>
<!-- endpanel -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>