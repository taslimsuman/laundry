<table class="table">
    <thead>
      <tr>
        <th scope="col">Inv#</th>
        <th scope="col">Date</th>
        <th scope="col">Customer</th>
        <th scope="col">Net Amount</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($inv->id); ?></th>
        <td><?php echo e($inv->idate); ?></td>
        <td ><a href="<?php echo e(url('/invoice',$inv->id)); ?>" target="_blank"><?php echo e($inv->customer_name); ?></a></td>
        <td><?php echo e($inv->net_amount); ?></td>
        <td>
          <a href="<?php echo e(url('/invoice',$inv->id)); ?>" target="_blank" class="btn btn-success">Open</a>
          <a href="<?php echo e(url('/invoice/delete',$inv->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure delete this invoice?');">
            <i class="fa fa-trash"></i></a>
        </td>
        
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($invoices->appends(Request::except('page'))->links()); ?>