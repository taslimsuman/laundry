<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<div class="panel panel-default">
   <div class="panel-heading">
      <h1 class="panel-title">Invoice</h3>
   </div>
    <div class="panel-body">
        <table class="table table-bordered">
          <tbody>
            <tr>
           
              <td><b>Invoice:</b> <?php echo e($inv->id); ?></td>
              <td><b>Date:</b> <?php echo e($inv->idate); ?></td>
              <td><b>Delivery:</b> <?php echo e($inv->del_date); ?></td>
              <td><b>Status:</b> <?php echo e($inv->status); ?></td>
              <td><b>Payment Status:</b> <?php echo e($inv->pay_status); ?></td>
            </tr>
            <tr>
              <td colspan="2"><b>Customer Name:</b> <?php echo e($inv->customer_name); ?></td>
              <td><b>Contact :</b> <?php echo e($inv->customer_contact); ?></td>
              <td colspan="2"><b>Address: </b> <?php echo e($inv->customer_address); ?></td>
              
            </tr>
            <tr>
              <td><b>Invoice Amount:</b> <?php echo e($inv->net_amount); ?> <?php echo e($home->currency); ?></td>
              <td><b>Pay:</b> <?php echo e($inv->payments->sum('pay')); ?> <?php echo e($home->currency); ?></td>
              <td><b>Due:</b> <?php echo e($inv->net_amount - $inv->payments->sum('pay')); ?> <?php echo e($home->currency); ?></td>
              <td><b>Type: </b> <?php echo e($inv->type); ?></td>
              
            </tr>
          </tbody>
        </table>

        <form action="<?php echo e(url('invoice/update/'.$inv->id)); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="row">
            <div class="col-md-2">
                <label>Status</label>
                <select class="form-control" name="status">
                  <option value="">Select</option>
                  <option value="Process">Process</option>
                  <option value="Ready">Ready</option>
                  
                </select>
              </div>
              <div class="col-md-6">
                <label>Note</label>
                <input type="text" name="note" value="<?php echo e($inv->note); ?>" class="form-control">
              </div>
              <div class="col-md-2">
                <label>Action</label><br>
                <input type="submit" value="Update" class="btn btn-success">
                <a href="<?php echo e(url('invoices')); ?>" class="btn btn-default">Close</a>
              </div>
          </div>
        </form>
  
    </div>
        <!-- panel -->
</div>

<div class="panel panel-info">
   <div class="panel-heading">
      <h1 class="panel-title">Payments</h3>
   </div>
    <div class="panel-body">
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>Date</th>
              <th>Pay note</th>
              <th>Payment</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $inv->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($pay->tdate); ?></td>
              <td><?php echo e($pay->pay_note); ?></td>
              <td><?php echo e($pay->pay); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

        <form action="<?php echo e(url('invoice/payment/'.$inv->id)); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="row">
              <div class="col-md-3">
                <label>Pay Note</label>
                <input type="text" name="pay_note" class="form-control">
              </div>
              <div class="col-md-2">
                <label>Amount</label>
                <input type="number" name="pay" class="form-control" min="1" required>
              </div>
              <div class="col-md-2">
                <label>Action</label><br>
                <input type="submit" value="Pay" class="btn btn-success">
                
              </div>
          </div>
        </form>
  
    </div>
        <!-- panel -->
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>