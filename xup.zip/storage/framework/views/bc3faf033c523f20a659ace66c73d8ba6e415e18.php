<?php $__env->startSection('header',strtoupper($status)); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="panel panel-default">
     <div class="panel-body">
     	 <form action="#" method="get">
          
          <div class="row">
          		<div class="col-md-2">
	            	<label>Invoice No</label>
	           		<input type="text" name="invoice" value="<?php echo e($param['invoice']); ?>" class="form-control">
	          	</div>

	            <div class="col-md-3">
	            <label>Name</label>
	           		<input type="text" name="name" value="<?php echo e($param['name']); ?>" class="form-control">
	          	</div>
              <div class="col-md-2">
                <label>Mobile No</label>
                <input type="text" name="contact" value="<?php echo e($param['contact']); ?>" class="form-control">
              </div>
              <div class="col-md-2">
                <label>Action</label><br>
                <input type="submit" value="Search" class="btn btn-success">
                <a href="<?php echo e(url('invoices')); ?>" class="btn btn-default">Cancel</a>
              </div>
          </div>
        </form>
        <hr>
       <?php echo $__env->make('invoice.invoice_table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
<!-- endpanel -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>