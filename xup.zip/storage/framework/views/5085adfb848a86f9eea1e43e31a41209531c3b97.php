<?php $__env->startSection('header','Invoices'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="panel panel-default">
     <div class="panel-body">
       <?php echo $__env->make('invoice.invoice_table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
<!-- endpanel -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>